0x0      coronet_bootloader.bin
0x8000   coronet_partitions.bin
0xe000   boot_app0.bin
0x10000  firmware.bin